%ennek ki kellene sz�molni Moran's I-t

%innen van a k�plet:
%https://en.wikipedia.org/wiki/Moran's_I

%bemenet 
%"a" 6x6-os vektor az adatokkal
%"w" 36x36-os vektor az �sszehasonl�t�sok t�rbeli s�lyaival

%els� k�rben egy 6x6-os mtx-on pr�b�lom ki
km=6;

%�tlag
atl=sum(sum(a))/numel(a);
%�tlagt�l val� elt�r�s
 b=a-atl;
 b2=b.^2;
 %leend� sz�ml�l�
 d=zeros(km^2,km^2);
 
 for i=1:km^2
     
     %d1=0;
    for j=1:km^2 
        %d1=d1+w(i,j)*b(i)*b(j);
        d(i,j)=w(i,j)*b(i)*b(j);
    end
    %d(i)=d1;
 end
 
 %Moran's I
 I=(numel(a)/sum(sum(w)))*(sum(sum(d))/sum(sum(b2)))
 %expected value
 E_I=-1/(numel(a)-1)