a = linspace(0,20,11)

b = 11:-2:-11

c = logspace(-3,4,8)

d = 2.^(0:10)

e = (-1).^(0:19)

f = linspace(0,1,6)

g1 = 0:2*pi/7:(2*pi-0.001)
% or
g2 = 0:2*pi/7:2*pi;
g2(8) = []