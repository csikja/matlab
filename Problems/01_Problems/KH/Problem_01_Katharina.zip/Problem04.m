km = input ('Type in a value in km: ');
disp([num2str(km), ' km = ', num2str(km*0.621371) ,' miles']);